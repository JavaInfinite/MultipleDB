**Do you want to request a *feature* or report a *bug*?**

**What is the current behavior?**

**If the current behavior is a bug, please provide the steps to reproduce:**

**What is the expected behavior?**

**Which versions of Java, Spring, and which OS are affected by this issue? Did this work in previous versions of Java or Spring?**
